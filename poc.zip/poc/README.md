# transmaster-router

HTTP reverse proxy in front of three Transaction Master APIs: **Legacy**, **OpenSearch**, and **ClickHouse**. It chooses an ordered route from the request date (or a sticky scroll token), forwards the call unchanged, and failovers on transport errors and configured HTTP statuses. The client always receives a real downstream status, headers, and body — including on failure.

This is not a BFF, aggregator, or service mesh. Query logic stays in the TM APIs.

## Package layout

```
router/src/main/java/com/tower/tmapi/router/
  RouterApplication.java
  web/RouterController.java      HTTP facade
  service/RouterService.java     date/token route + failover chain
  client/DownstreamClient.java   one HTTP hop (only class that calls downstream)
  model/DownstreamApi.java       LEGACY | OPEN_SEARCH | CLICK_HOUSE
  model/DownstreamResponse.java
  config/RouterProperties.java   router.* YAML
  config/RouterConfig.java       RestClient + circuit breakers
  util/LegacyRequestRewriter.java  ISO dates → Legacy arrays
```

Java **25**. Wire this package into the `tm-apis` `router` Maven module (artifact `router`, Spring Boot app `transmaster-router`).

## Public paths

| Prefix | Typical date source |
| --- | --- |
| `/executions/**` | Body `filterCriteria.run_date` / `trade_date` (min), else query `date` |
| `/aggregatedExecutions/**` | Same as executions |
| `/milestones/**` | Query `date` |

Method, path, query, and body are forwarded as-is. Hop-by-hop headers are stripped. `Access-token` is passed through; the router does not authenticate.

## Routing

Cutover (`yyyyMMdd`), invariant `opensearch-start < clickhouse-start`:

| Date | Route |
| --- | --- |
| missing / unparseable | `[LEGACY]` |
| `date < opensearch-start` | `[LEGACY]` |
| `opensearch-start ≤ date < clickhouse-start` | `[OPEN_SEARCH, LEGACY]` |
| `date ≥ clickhouse-start` | `[CLICK_HOUSE, OPEN_SEARCH, LEGACY]` |

Mixed dates use the **earliest**.

If `lastScrollId` decodes to `PROD` / `OS` / `CH`, the route is that single API. Failures do **not** hop mid-scroll.

## Failover

Tried on:

- connect / timeout / other I/O (`router.failover.on-connect-failure`)
- open circuit breaker
- HTTP statuses in `router.failover.status-codes` (default `404, 500, 502, 503, 504`)

Never on `400` / `401` / `403` unless you add them to the list.

If every hop is failover-eligible, the **last** downstream status/headers/body is returned (not an empty invented 502).

## Configuration

```yaml
router:
  expose-routed-to-header: true
  targets:
    legacy:     { base-url: http://post-trade.tower-research.com/transmaster }
    opensearch: { base-url: http://transmaster-opensearch:8080 }
    clickhouse: { base-url: http://transmaster-clickhouse:8081 }
  cutover:
    opensearch-start: "20240701"
    clickhouse-start: "20240901"
  failover:
    status-codes: [404, 500, 502, 503, 504]
    on-connect-failure: true
    circuit-failure-threshold: 5
    circuit-open-duration-ms: 30000
  timeouts:
    connect-ms: 5000
    read-ms: 120000
```

Optional response header `X-TM-Routed-To` names the winning API. Every response includes `X-Correlation-Id` (echoed or generated).

## Observability

MDC: `correlationId`, `method`, `path`, `route`, `downstreamApi`, `status`, `durationMs`. Do not log full bodies (PII).

Micrometer: `router.latency`, `router.proxy` (result=`success`/`error`/`circuit_open`/`terminal`), `router.fallback` (`from`/`to`).

Actuator: health, info, metrics; readiness at `/actuator/health/readinessState`.

## Tests

```bash
mvn -pl router test
```

Unit tests live under `router/src/test/java/com/tower/tmapi/router/` and cover routing bands, sticky scroll, failover vs `400`, last-error body, RestClient error capture, legacy date rewrite, and the controller copy-out path.

## Out of scope

Removing window routing from OpenSearch, Dockerfile/OAM/ingress cutover, path rewriting between OS and CH, merging responses across APIs.
