package com.tower.tmapi.router.config;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;

import com.tower.tmapi.router.model.DownstreamApi;

import jakarta.annotation.PostConstruct;

/**
 * Binds {@code router.*} configuration: target URLs, cutover dates, failover, and timeouts.
 */
@ConfigurationProperties(prefix = "router")
public class RouterProperties {

    private static final DateTimeFormatter BASIC_ISO = DateTimeFormatter.BASIC_ISO_DATE;

    private boolean exposeRoutedToHeader = false;
    private Map<String, Target> targets = Map.of();
    private Cutover cutover = new Cutover();
    private Failover failover = new Failover();
    private Timeouts timeouts = new Timeouts();

    /**
     * Fails startup when cutover dates are inverted or a target URL is missing.
     *
     * @throws IllegalStateException when configuration is invalid
     */
    @PostConstruct
    public void validate() {
        LocalDate openSearchStart = cutover.openSearchStartDate();
        LocalDate clickHouseStart = cutover.clickHouseStartDate();
        if (!openSearchStart.isBefore(clickHouseStart)) {
            throw new IllegalStateException(
                    "router.cutover.opensearch-start must be before clickhouse-start");
        }
        for (DownstreamApi api : DownstreamApi.values()) {
            baseUrlFor(api);
        }
    }

    /**
     * @param api downstream API
     * @return configured base URL
     * @throws IllegalStateException when the URL is missing
     */
    public String baseUrlFor(DownstreamApi api) {
        Target target = targets.get(configKey(api));
        if (target == null || target.getBaseUrl() == null || target.getBaseUrl().isBlank()) {
            throw new IllegalStateException("Missing router.targets." + configKey(api) + ".base-url");
        }
        return target.getBaseUrl();
    }

    /**
     * @return base URL for every {@link DownstreamApi}
     */
    public Map<DownstreamApi, String> baseUrls() {
        Map<DownstreamApi, String> urls = new EnumMap<>(DownstreamApi.class);
        for (DownstreamApi api : DownstreamApi.values()) {
            urls.put(api, baseUrlFor(api));
        }
        return urls;
    }

    /**
     * @param api downstream API
     * @return YAML map key under {@code router.targets}
     */
    private static String configKey(DownstreamApi api) {
        return switch (api) {
            case LEGACY -> "legacy";
            case OPEN_SEARCH -> "opensearch";
            case CLICK_HOUSE -> "clickhouse";
        };
    }

    /**
     * @return whether to add {@code X-TM-Routed-To} on the client response
     */
    public boolean isExposeRoutedToHeader() {
        return exposeRoutedToHeader;
    }

    /**
     * @param exposeRoutedToHeader {@code router.expose-routed-to-header}
     */
    public void setExposeRoutedToHeader(boolean exposeRoutedToHeader) {
        this.exposeRoutedToHeader = exposeRoutedToHeader;
    }

    /**
     * @return named targets ({@code legacy}, {@code opensearch}, {@code clickhouse})
     */
    public Map<String, Target> getTargets() {
        return targets;
    }

    /**
     * @param targets named targets; {@code null} becomes empty
     */
    public void setTargets(Map<String, Target> targets) {
        this.targets = targets == null ? Map.of() : targets;
    }

    /**
     * @return cutover date bounds
     */
    public Cutover getCutover() {
        return cutover;
    }

    /**
     * @param cutover cutover dates; {@code null} becomes defaults
     */
    public void setCutover(Cutover cutover) {
        this.cutover = cutover == null ? new Cutover() : cutover;
    }

    /**
     * @return failover policy
     */
    public Failover getFailover() {
        return failover;
    }

    /**
     * @param failover failover policy; {@code null} becomes defaults
     */
    public void setFailover(Failover failover) {
        this.failover = failover == null ? new Failover() : failover;
    }

    /**
     * @return HTTP client timeouts
     */
    public Timeouts getTimeouts() {
        return timeouts;
    }

    /**
     * @param timeouts HTTP timeouts; {@code null} becomes defaults
     */
    public void setTimeouts(Timeouts timeouts) {
        this.timeouts = timeouts == null ? new Timeouts() : timeouts;
    }

    /**
     * One downstream base URL.
     */
    public static class Target {
        private String baseUrl;

        /**
         * @return {@code router.targets.*.base-url}
         */
        public String getBaseUrl() {
            return baseUrl;
        }

        /**
         * @param baseUrl origin used by {@link org.springframework.web.client.RestClient}
         */
        public void setBaseUrl(String baseUrl) {
            this.baseUrl = baseUrl;
        }
    }

    /**
     * Inclusive start dates for OpenSearch and ClickHouse bands ({@code yyyyMMdd}).
     */
    public static class Cutover {
        private String opensearchStart = "20240101";
        private String clickhouseStart = "20240601";

        /**
         * @return first date served by OpenSearch
         */
        public LocalDate openSearchStartDate() {
            return parse(opensearchStart, "router.cutover.opensearch-start");
        }

        /**
         * @return first date served by ClickHouse
         */
        public LocalDate clickHouseStartDate() {
            return parse(clickhouseStart, "router.cutover.clickhouse-start");
        }

        /**
         * @param value     {@code yyyyMMdd}
         * @param property  config key used in the error message
         * @return parsed date
         */
        private static LocalDate parse(String value, String property) {
            try {
                return LocalDate.parse(value, BASIC_ISO);
            } catch (DateTimeParseException | NullPointerException e) {
                throw new IllegalStateException(property + " must be yyyyMMdd, got: " + value, e);
            }
        }

        /**
         * @return raw OpenSearch start
         */
        public String getOpensearchStart() {
            return opensearchStart;
        }

        /**
         * @param opensearchStart {@code yyyyMMdd}
         */
        public void setOpensearchStart(String opensearchStart) {
            this.opensearchStart = opensearchStart;
        }

        /**
         * @return raw ClickHouse start
         */
        public String getClickhouseStart() {
            return clickhouseStart;
        }

        /**
         * @param clickhouseStart {@code yyyyMMdd}
         */
        public void setClickhouseStart(String clickhouseStart) {
            this.clickhouseStart = clickhouseStart;
        }
    }

    /**
     * When to try the next API in the route.
     */
    public static class Failover {
        private List<Integer> statusCodes = List.of(404, 500, 502, 503, 504);
        private boolean onConnectFailure = true;
        private int circuitFailureThreshold = 5;
        private long circuitOpenDurationMs = 30_000;

        /**
         * @return HTTP statuses that trigger failover
         */
        public Set<Integer> statusCodeSet() {
            return Set.copyOf(statusCodes);
        }

        /**
         * @return configured failover statuses
         */
        public List<Integer> getStatusCodes() {
            return statusCodes;
        }

        /**
         * @param statusCodes {@code router.failover.status-codes}; {@code null} becomes empty
         */
        public void setStatusCodes(List<Integer> statusCodes) {
            this.statusCodes = statusCodes == null ? List.of() : List.copyOf(statusCodes);
        }

        /**
         * @return whether connect/timeout errors failover
         */
        public boolean isOnConnectFailure() {
            return onConnectFailure;
        }

        /**
         * @param onConnectFailure {@code router.failover.on-connect-failure}
         */
        public void setOnConnectFailure(boolean onConnectFailure) {
            this.onConnectFailure = onConnectFailure;
        }

        /**
         * @return consecutive failures before the circuit opens
         */
        public int getCircuitFailureThreshold() {
            return circuitFailureThreshold;
        }

        /**
         * @param circuitFailureThreshold {@code router.failover.circuit-failure-threshold}
         */
        public void setCircuitFailureThreshold(int circuitFailureThreshold) {
            this.circuitFailureThreshold = circuitFailureThreshold;
        }

        /**
         * @return how long an open circuit stays open
         */
        public long getCircuitOpenDurationMs() {
            return circuitOpenDurationMs;
        }

        /**
         * @param circuitOpenDurationMs {@code router.failover.circuit-open-duration-ms}
         */
        public void setCircuitOpenDurationMs(long circuitOpenDurationMs) {
            this.circuitOpenDurationMs = circuitOpenDurationMs;
        }
    }

    /**
     * Connect and read timeouts for downstream {@code RestClient}s.
     */
    public static class Timeouts {
        private int connectMs = 5000;
        private int readMs = 120_000;

        /**
         * @return connect timeout in milliseconds
         */
        public int getConnectMs() {
            return connectMs;
        }

        /**
         * @param connectMs {@code router.timeouts.connect-ms}
         */
        public void setConnectMs(int connectMs) {
            this.connectMs = connectMs;
        }

        /**
         * @return read timeout in milliseconds
         */
        public int getReadMs() {
            return readMs;
        }

        /**
         * @param readMs {@code router.timeouts.read-ms}
         */
        public void setReadMs(int readMs) {
            this.readMs = readMs;
        }
    }
}
