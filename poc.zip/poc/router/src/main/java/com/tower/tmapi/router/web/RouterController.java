package com.tower.tmapi.router.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tower.tmapi.router.config.RouterProperties;
import com.tower.tmapi.router.model.DownstreamResponse;
import com.tower.tmapi.router.service.RouterService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * HTTP facade for TM API path prefixes. Buffers the body, calls {@link RouterService},
 * and copies the downstream status, headers, and body to the client.
 */
@RestController
public class RouterController {

    /**
     * Optional debug header naming the API that produced the response.
     */
    static final String ROUTED_TO_HEADER = "X-TM-Routed-To";

    /**
     * Correlation id echoed on every response; reused when the client sent one.
     */
    static final String CORRELATION_HEADER = "X-Correlation-Id";

    private static final Logger log = LoggerFactory.getLogger(RouterController.class);
    private static final Set<String> SKIP_RESPONSE_HEADERS = Set.of(
            "content-length", "transfer-encoding");

    private final RouterService routerService;
    private final RouterProperties properties;

    /**
     * @param routerService routing and failover
     * @param properties    header exposure flags
     */
    public RouterController(RouterService routerService, RouterProperties properties) {
        this.routerService = routerService;
        this.properties = properties;
    }

    /**
     * Catch-all proxy for executions, aggregated executions, and milestones.
     *
     * @param request  inbound request
     * @param response outbound response
     * @throws IOException when the body cannot be read or written
     */
    @RequestMapping({
            "/executions/**",
            "/aggregatedExecutions/**",
            "/milestones/**"
    })
    public void proxy(HttpServletRequest request, HttpServletResponse response) throws IOException {
        long started = System.currentTimeMillis();
        String correlationId = correlationId(request);
        MDC.put("correlationId", correlationId);
        MDC.put("method", request.getMethod());
        MDC.put("path", request.getRequestURI());
        try {
            byte[] body = request.getInputStream().readAllBytes();
            DownstreamResponse result = routerService.route(request, body);
            write(response, result, correlationId);
            long durationMs = System.currentTimeMillis() - started;
            MDC.put("status", Integer.toString(result.statusCode()));
            MDC.put("durationMs", Long.toString(durationMs));
            log.info("Completed proxy status={} durationMs={} api={}",
                    result.statusCode(), durationMs, result.api());
        } finally {
            MDC.clear();
        }
    }

    /**
     * Copies status, headers, and body. Skips hop-by-hop length/encoding headers.
     *
     * @param response      servlet response
     * @param result        downstream hop
     * @param correlationId value for {@link #CORRELATION_HEADER}
     * @throws IOException when writing the body fails
     */
    private void write(HttpServletResponse response, DownstreamResponse result, String correlationId)
            throws IOException {
        response.setStatus(result.statusCode());
        response.setHeader(CORRELATION_HEADER, correlationId);

        for (Map.Entry<String, List<String>> header : result.headers().entrySet()) {
            String name = header.getKey();
            if (name == null || SKIP_RESPONSE_HEADERS.contains(name.toLowerCase())) {
                continue;
            }
            for (String value : header.getValue()) {
                response.addHeader(name, value);
            }
        }

        if (properties.isExposeRoutedToHeader() && result.api() != null) {
            response.setHeader(ROUTED_TO_HEADER, result.api().name());
        }

        byte[] body = result.bodyOrEmpty();
        if (body.length > 0 && response.getContentType() == null) {
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        }
        if (body.length > 0) {
            response.setContentLength(body.length);
            response.getOutputStream().write(body);
        }
        response.flushBuffer();
    }

    /**
     * @param request inbound request
     * @return existing {@link #CORRELATION_HEADER} or a generated UUID
     */
    private static String correlationId(HttpServletRequest request) {
        String inbound = request.getHeader(CORRELATION_HEADER);
        if (inbound != null && !inbound.isBlank()) {
            return inbound;
        }
        return UUID.randomUUID().toString();
    }
}
