package com.tower.tmapi.router.model;

import java.util.Optional;

/**
 * The three Transaction Master HTTP APIs this router can call.
 * Token {@code src} values match continuation tokens from {@code ContinuationTokenCodec}:
 * {@code PROD}, {@code OS}, {@code CH}.
 */
public enum DownstreamApi {

    /** Archive / production TM ({@code transmaster}). */
    LEGACY("PROD"),

    /** OpenSearch TM APIs. */
    OPEN_SEARCH("OS"),

    /** ClickHouse TM APIs. */
    CLICK_HOUSE("CH");

    private final String tokenSrc;

    /**
     * @param tokenSrc continuation-token source string for sticky pagination
     */
    DownstreamApi(String tokenSrc) {
        this.tokenSrc = tokenSrc;
    }

    /**
     * @return opaque {@code src} stored in scroll continuation tokens
     */
    public String tokenSrc() {
        return tokenSrc;
    }

    /**
     * Resolves a decoded continuation-token source to an API.
     *
     * @param source {@code PROD}, {@code OS}, or {@code CH}
     * @return matching API, or empty when the source is null, blank, or unknown
     */
    public static Optional<DownstreamApi> fromTokenSrc(String source) {
        if (source == null || source.isBlank()) {
            return Optional.empty();
        }
        for (DownstreamApi api : values()) {
            if (api.tokenSrc.equals(source)) {
                return Optional.of(api);
            }
        }
        return Optional.empty();
    }
}
