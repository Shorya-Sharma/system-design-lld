package com.tower.tmapi.router.model;

import java.util.List;
import java.util.Map;

/**
 * Outcome of one hop to a {@link DownstreamApi}.
 * Always includes the downstream status and body so the caller can return them,
 * including when the hop failed.
 *
 * @param api               API that was called
 * @param statusCode        HTTP status from the hop, or 502/503 when no HTTP response
 * @param body              response bytes; never {@code null} after {@link #of}
 * @param headers           response headers; never {@code null} after {@link #of}
 * @param failoverEligible  {@code true} for I/O, timeout, or open circuit (not for HTTP statuses)
 */
public record DownstreamResponse(
        DownstreamApi api,
        int statusCode,
        byte[] body,
        Map<String, List<String>> headers,
        boolean failoverEligible
) {
    /**
     * @return response body, or an empty array when {@code body} is {@code null}
     */
    public byte[] bodyOrEmpty() {
        return body == null ? new byte[0] : body;
    }

    /**
     * Factory that normalizes null body and headers.
     *
     * @param api               API that was called
     * @param statusCode        HTTP or synthetic status
     * @param body              may be {@code null}
     * @param headers           may be {@code null}
     * @param failoverEligible  whether {@link com.tower.tmapi.router.service.RouterService} may try the next API
     * @return response with non-null body and headers
     */
    public static DownstreamResponse of(
            DownstreamApi api,
            int statusCode,
            byte[] body,
            Map<String, List<String>> headers,
            boolean failoverEligible) {
        return new DownstreamResponse(
                api,
                statusCode,
                body == null ? new byte[0] : body,
                headers == null ? Map.of() : headers,
                failoverEligible);
    }
}
