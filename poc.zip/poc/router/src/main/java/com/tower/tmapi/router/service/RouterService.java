package com.tower.tmapi.router.service;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tower.tmapi.router.client.DownstreamClient;
import com.tower.tmapi.router.config.RouterProperties;
import com.tower.tmapi.router.model.DownstreamApi;
import com.tower.tmapi.router.model.DownstreamResponse;

import io.micrometer.core.instrument.MeterRegistry;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Builds the ordered {@link DownstreamApi} list and walks it until a terminal hop.
 * HTTP I/O is delegated to {@link DownstreamClient}.
 */
@Service
public class RouterService {

    private static final Logger log = LoggerFactory.getLogger(RouterService.class);
    private static final DateTimeFormatter BASIC_ISO = DateTimeFormatter.BASIC_ISO_DATE;
    private static final DateTimeFormatter ISO_DATE = DateTimeFormatter.ISO_LOCAL_DATE;

    private final DownstreamClient downstreamClient;
    private final RouterProperties properties;
    private final ObjectMapper objectMapper;
    private final MeterRegistry meterRegistry;

    /**
     * @param downstreamClient single-hop HTTP adapter
     * @param properties       cutover and failover settings
     * @param objectMapper     JSON parser for {@code filterCriteria} dates
     * @param meterRegistry    fallback counters
     */
    public RouterService(
            DownstreamClient downstreamClient,
            RouterProperties properties,
            ObjectMapper objectMapper,
            MeterRegistry meterRegistry) {
        this.downstreamClient = downstreamClient;
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.meterRegistry = meterRegistry;
    }

    /**
     * Routes one inbound request and returns the winning or last downstream response.
     *
     * @param request inbound HTTP request
     * @param body    buffered entity
     * @return response to copy back to the client
     */
    public DownstreamResponse route(HttpServletRequest request, byte[] body) {
        Optional<DownstreamApi> sticky = stickyApi(request.getParameter("lastScrollId"));
        LocalDate date = representativeDate(request, body);
        List<DownstreamApi> plan = planRoute(date, sticky.orElse(null));
        String route = plan.stream().map(Enum::name).collect(Collectors.joining("->"));
        MDC.put("route", route);

        log.info("Routing method={} path={} date={} sticky={} route={}",
                request.getMethod(), request.getRequestURI(), date, sticky.orElse(null), route);

        DownstreamResponse last = null;
        for (int i = 0; i < plan.size(); i++) {
            DownstreamApi api = plan.get(i);
            MDC.put("downstreamApi", api.name());
            DownstreamResponse hop = downstreamClient.exchange(api, request, body);
            last = hop;

            boolean failover = isFailover(hop);
            log.info("Hop api={} status={} failoverEligible={}", api, hop.statusCode(), failover);

            if (!failover) {
                meterRegistry.counter("router.proxy", "api", api.name(), "result", "terminal").increment();
                return hop;
            }

            boolean hasNext = i + 1 < plan.size();
            if (hasNext) {
                DownstreamApi next = plan.get(i + 1);
                meterRegistry.counter("router.fallback", "from", api.name(), "to", next.name()).increment();
                log.warn("Failing over from={} to={} status={}", api, next, hop.statusCode());
            }
        }

        log.warn("Route exhausted; returning last response api={} status={}",
                last == null ? null : last.api(), last == null ? null : last.statusCode());
        if (last == null) {
            throw new IllegalStateException("Route plan was empty");
        }
        return last;
    }

    /**
     * Strategy: sticky token pins one API; otherwise band by cutover dates.
     *
     * @param date   representative trade/run date; {@code null} means Legacy only
     * @param sticky decoded continuation API, or {@code null}
     * @return primary then fallbacks
     */
    List<DownstreamApi> planRoute(LocalDate date, DownstreamApi sticky) {
        if (sticky != null) {
            return List.of(sticky);
        }
        if (date == null) {
            return List.of(DownstreamApi.LEGACY);
        }
        LocalDate openSearchStart = properties.getCutover().openSearchStartDate();
        LocalDate clickHouseStart = properties.getCutover().clickHouseStartDate();
        if (date.isBefore(openSearchStart)) {
            return List.of(DownstreamApi.LEGACY);
        }
        if (date.isBefore(clickHouseStart)) {
            return List.of(DownstreamApi.OPEN_SEARCH, DownstreamApi.LEGACY);
        }
        return List.of(DownstreamApi.CLICK_HOUSE, DownstreamApi.OPEN_SEARCH, DownstreamApi.LEGACY);
    }

    /**
     * @param hop hop result
     * @return {@code true} when the next API in the plan should be tried
     */
    private boolean isFailover(DownstreamResponse hop) {
        if (hop.failoverEligible()) {
            if (hop.statusCode() == 503) {
                return true;
            }
            return properties.getFailover().isOnConnectFailure();
        }
        return properties.getFailover().statusCodeSet().contains(hop.statusCode());
    }

    /**
     * @param lastScrollId query {@code lastScrollId}
     * @return sticky API when the token starts with {@code PROD}, {@code OS}, or {@code CH}
     */
    private Optional<DownstreamApi> stickyApi(String lastScrollId) {
        if (lastScrollId == null || lastScrollId.isBlank()) {
            return Optional.empty();
        }
        for (DownstreamApi api : DownstreamApi.values()) {
            String src = api.tokenSrc();
            if (lastScrollId.equals(src)
                    || lastScrollId.startsWith(src + ":")
                    || lastScrollId.startsWith(src + ".")
                    || lastScrollId.startsWith(src + "|")) {
                return Optional.of(api);
            }
        }
        return DownstreamApi.fromTokenSrc(lastScrollId);
    }

    /**
     * @param request inbound request
     * @param body    JSON body
     * @return earliest date from query and {@code filterCriteria}, or {@code null}
     */
    private LocalDate representativeDate(HttpServletRequest request, byte[] body) {
        List<LocalDate> dates = new ArrayList<>();
        parseDate(request.getParameter("date")).ifPresent(dates::add);
        parseDate(request.getParameter("dateFrom")).ifPresent(dates::add);
        parseDate(request.getParameter("tradeDate")).ifPresent(dates::add);
        dates.addAll(datesFromBody(body));
        return dates.stream().min(LocalDate::compareTo).orElse(null);
    }

    /**
     * @param body request JSON
     * @return dates from {@code filterCriteria.run_date}, {@code trade_date}, {@code dateFrom}, {@code minDate}
     */
    private List<LocalDate> datesFromBody(byte[] body) {
        if (body == null || body.length == 0) {
            return List.of();
        }
        try {
            JsonNode root = objectMapper.readTree(body);
            if (root == null || !root.isObject()) {
                return List.of();
            }
            JsonNode filter = root.get("filterCriteria");
            if (filter == null || !filter.isObject()) {
                return List.of();
            }
            List<LocalDate> dates = new ArrayList<>();
            collect(filter.get("run_date"), dates);
            collect(filter.get("trade_date"), dates);
            collect(filter.get("dateFrom"), dates);
            collect(filter.get("minDate"), dates);
            return dates;
        } catch (Exception e) {
            log.debug("Could not parse dates from body: {}", e.toString());
            return List.of();
        }
    }

    /**
     * Adds dates from a JSON node that may be a scalar, list of scalars, or {@code [y,M,d,...]}.
     *
     * @param node  JSON value
     * @param dates accumulator
     */
    private static void collect(JsonNode node, List<LocalDate> dates) {
        if (node == null || node.isNull()) {
            return;
        }
        if (node.isArray() && looksLikeDateArray(node)) {
            parseDateArray(node).ifPresent(dates::add);
            return;
        }
        if (node.isArray()) {
            for (JsonNode child : node) {
                parseNode(child).ifPresent(dates::add);
            }
            return;
        }
        parseNode(node).ifPresent(dates::add);
    }

    /**
     * @param node JSON array
     * @return {@code true} when the array looks like {@code [year, month, day, ...]}
     */
    private static boolean looksLikeDateArray(JsonNode node) {
        return node.size() >= 3 && node.get(0) != null && node.get(0).isNumber();
    }

    /**
     * @param node text, epoch, or date array
     * @return parsed date
     */
    private static Optional<LocalDate> parseNode(JsonNode node) {
        if (node == null || node.isNull()) {
            return Optional.empty();
        }
        if (node.isTextual()) {
            return parseDate(node.asText());
        }
        if (node.isNumber()) {
            long n = node.asLong();
            if (n > 10_000_000_000L) {
                return Optional.of(Instant.ofEpochMilli(n).atZone(ZoneOffset.UTC).toLocalDate());
            }
            if (n > 1_000_000_000L) {
                return Optional.of(Instant.ofEpochSecond(n).atZone(ZoneOffset.UTC).toLocalDate());
            }
        }
        if (node.isArray()) {
            return parseDateArray(node);
        }
        return Optional.empty();
    }

    /**
     * @param node JSON array of at least year, month, day
     * @return calendar date
     */
    private static Optional<LocalDate> parseDateArray(JsonNode node) {
        try {
            int year = node.get(0).asInt();
            int month = node.get(1).asInt();
            int day = node.get(2).asInt();
            if (year > 0 && month > 0 && day > 0) {
                return Optional.of(LocalDate.of(year, month, day));
            }
        } catch (Exception ignored) {
            return Optional.empty();
        }
        return Optional.empty();
    }

    /**
     * @param raw {@code yyyyMMdd} or ISO {@code yyyy-MM-dd} (optionally with time)
     * @return parsed date
     */
    static Optional<LocalDate> parseDate(String raw) {
        if (raw == null || raw.isBlank()) {
            return Optional.empty();
        }
        String value = raw.trim();
        try {
            if (value.length() == 8 && value.chars().allMatch(Character::isDigit)) {
                return Optional.of(LocalDate.parse(value, BASIC_ISO));
            }
            if (value.length() >= 10) {
                return Optional.of(LocalDate.parse(value.substring(0, 10), ISO_DATE));
            }
        } catch (Exception ignored) {
            return Optional.empty();
        }
        return Optional.empty();
    }
}
