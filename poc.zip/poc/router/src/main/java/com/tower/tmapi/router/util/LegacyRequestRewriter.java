package com.tower.tmapi.router.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/**
 * Rewrites ISO local date-times to Legacy TM {@code [year, month, day, hour, minute]}
 * arrays on the historical ProdTradesClient POST paths.
 */
@Component
public class LegacyRequestRewriter {

    private static final Logger log = LoggerFactory.getLogger(LegacyRequestRewriter.class);
    private static final DateTimeFormatter ISO_LOCAL = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private static final String[] REWRITE_PATHS = {
            "/executions/aggregatedExecutions",
            "/allocations/aggregatedAllocations",
            "/executions/getAggregatedTrade",
            "/allocations/getAggregatedTrade"
    };
    private static final String[] DATE_FIELDS = {"dateFrom", "minDate", "startTime", "endTime"};

    private final ObjectMapper objectMapper;

    /**
     * @param objectMapper JSON reader/writer used for the rewrite
     */
    public LegacyRequestRewriter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    /**
     * Returns a rewritten body for known legacy POST paths; otherwise the original bytes.
     *
     * @param requestPath  inbound URI
     * @param originalBody request entity; may be {@code null}
     * @return bytes to send to Legacy TM
     */
    public byte[] maybeRewrite(String requestPath, byte[] originalBody) {
        if (requestPath == null || originalBody == null || originalBody.length == 0) {
            return originalBody;
        }
        if (!requiresRewrite(requestPath)) {
            return originalBody;
        }
        try {
            JsonNode root = objectMapper.readTree(originalBody);
            boolean changed = false;
            for (String field : DATE_FIELDS) {
                changed |= rewriteField(root, field);
            }
            if (changed) {
                return objectMapper.writeValueAsBytes(root);
            }
        } catch (Exception e) {
            log.debug("Skipping legacy body rewrite path={}: {}", requestPath, e.toString());
        }
        return originalBody;
    }

    /**
     * @param requestPath inbound URI
     * @return {@code true} when the path is one of the ProdTradesClient rewrite endpoints
     */
    private static boolean requiresRewrite(String requestPath) {
        String normalized = stripTrailingSlash(requestPath);
        for (String path : REWRITE_PATHS) {
            if (normalized.endsWith(path)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param path request URI
     * @return path without a trailing slash (except {@code /})
     */
    private static String stripTrailingSlash(String path) {
        if (path.length() > 1 && path.endsWith("/")) {
            return path.substring(0, path.length() - 1);
        }
        return path;
    }

    /**
     * Replaces a date-time field on {@code filterCriteria} (or the root object) with a 5-int array.
     *
     * @param root      JSON object
     * @param fieldName {@code dateFrom}, {@code minDate}, {@code startTime}, or {@code endTime}
     * @return {@code true} when the tree was mutated
     */
    private boolean rewriteField(JsonNode root, String fieldName) {
        if (root == null || !root.isObject()) {
            return false;
        }
        JsonNode filterCriteria = root.get("filterCriteria");
        JsonNode holder = (filterCriteria != null && filterCriteria.isObject()) ? filterCriteria : root;
        JsonNode value = holder.get(fieldName);
        if (value == null || value.isNull()) {
            return false;
        }
        LocalDateTime parsed = parseIsoDateTime(value);
        if (parsed == null) {
            return false;
        }
        ArrayNode array = objectMapper.createArrayNode();
        array.add(parsed.getYear());
        array.add(parsed.getMonthValue());
        array.add(parsed.getDayOfMonth());
        array.add(parsed.getHour());
        array.add(parsed.getMinute());
        ((ObjectNode) holder).set(fieldName, array);
        return true;
    }

    /**
     * @param value textual ISO-8601 local date-time or an existing 5-int array
     * @return parsed value, or {@code null} when the node is not a date-time
     */
    private static LocalDateTime parseIsoDateTime(JsonNode value) {
        if (value.isTextual()) {
            try {
                return LocalDateTime.parse(value.asText(), ISO_LOCAL);
            } catch (DateTimeParseException e) {
                return null;
            }
        }
        if (value.isArray() && value.size() >= 5) {
            try {
                int year = value.get(0).asInt();
                int month = value.get(1).asInt();
                int day = value.get(2).asInt();
                int hour = value.get(3).asInt();
                int minute = value.get(4).asInt();
                if (year > 0 && month > 0 && day > 0) {
                    return LocalDateTime.of(year, month, day, hour, minute);
                }
            } catch (Exception ignored) {
                return null;
            }
        }
        return null;
    }
}
