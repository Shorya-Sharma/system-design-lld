package com.tower.tmapi.router.config;

import java.net.http.HttpClient;
import java.time.Duration;
import java.util.EnumMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tower.tmapi.router.model.DownstreamApi;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

/**
 * Infrastructure beans: Jackson, per-API {@link RestClient}s, and Resilience4j circuit breakers.
 */
@Configuration
public class RouterConfig {

    /**
     * Explicit Jackson 2 mapper for body date parsing and legacy rewrite.
     * Spring Boot 4 may auto-configure Jackson 3 instead of this type.
     *
     * @return shared {@link ObjectMapper}
     */
    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    /**
     * One {@link RestClient} per {@link DownstreamApi}, sharing connect/read timeouts.
     * HTTP 4xx/5xx are returned as responses, not thrown as exceptions.
     *
     * @param properties router configuration
     * @return immutable map of clients
     */
    @Bean
    public Map<DownstreamApi, RestClient> downstreamRestClients(RouterProperties properties) {
        Map<DownstreamApi, RestClient> clients = new EnumMap<>(DownstreamApi.class);
        Duration connect = Duration.ofMillis(properties.getTimeouts().getConnectMs());
        Duration read = Duration.ofMillis(properties.getTimeouts().getReadMs());

        for (DownstreamApi api : DownstreamApi.values()) {
            HttpClient httpClient = HttpClient.newBuilder()
                    .connectTimeout(connect)
                    .build();
            JdkClientHttpRequestFactory factory = new JdkClientHttpRequestFactory(httpClient);
            factory.setReadTimeout(read);
            clients.put(api, RestClient.builder()
                    .baseUrl(properties.baseUrlFor(api))
                    .requestFactory(factory)
                    .defaultStatusHandler(HttpStatusCode::isError, (request, response) -> {
                    })
                    .build());
        }
        return Map.copyOf(clients);
    }

    /**
     * Per-API circuit breakers aligned to {@code router.failover} threshold and open duration.
     *
     * @param properties router configuration
     * @return registry with a breaker named after each {@link DownstreamApi}
     */
    @Bean
    public CircuitBreakerRegistry circuitBreakerRegistry(RouterProperties properties) {
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                .failureRateThreshold(100)
                .minimumNumberOfCalls(properties.getFailover().getCircuitFailureThreshold())
                .slidingWindowSize(Math.max(properties.getFailover().getCircuitFailureThreshold(), 1))
                .waitDurationInOpenState(Duration.ofMillis(properties.getFailover().getCircuitOpenDurationMs()))
                .build();
        CircuitBreakerRegistry registry = CircuitBreakerRegistry.of(config);
        for (DownstreamApi api : DownstreamApi.values()) {
            registry.circuitBreaker(api.name());
        }
        return registry;
    }
}
