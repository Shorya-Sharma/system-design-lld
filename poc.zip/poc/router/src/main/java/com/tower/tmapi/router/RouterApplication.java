package com.tower.tmapi.router;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.tower.tmapi.router.config.RouterProperties;

/**
 * Spring Boot entry point for the Transaction Master API router.
 * <p>
 * The process is a reverse proxy: it selects Legacy, OpenSearch, or ClickHouse
 * from the request date (or a sticky scroll token) and forwards HTTP unchanged.
 */
@SpringBootApplication
@EnableConfigurationProperties(RouterProperties.class)
public class RouterApplication {

    /**
     * Starts the router process.
     *
     * @param args standard Spring Boot arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(RouterApplication.class, args);
    }
}
