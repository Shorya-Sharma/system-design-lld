package com.tower.tmapi.router.client;

import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import com.tower.tmapi.router.model.DownstreamApi;
import com.tower.tmapi.router.model.DownstreamResponse;
import com.tower.tmapi.router.util.LegacyRequestRewriter;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Performs a single HTTP call to one {@link DownstreamApi}.
 * Does not choose routes or walk fallbacks.
 */
@Component
public class DownstreamClient {

    private static final Logger log = LoggerFactory.getLogger(DownstreamClient.class);

    private static final Set<String> HOP_BY_HOP = Set.of(
            "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
            "te", "trailer", "transfer-encoding", "upgrade", "host", "content-length");

    private final Map<DownstreamApi, RestClient> clients;
    private final LegacyRequestRewriter legacyRequestRewriter;
    private final CircuitBreakerRegistry circuitBreakerRegistry;
    private final MeterRegistry meterRegistry;

    /**
     * @param downstreamRestClients  RestClient per API
     * @param legacyRequestRewriter  applied only on {@link DownstreamApi#LEGACY}
     * @param circuitBreakerRegistry per-API circuit breakers
     * @param meterRegistry          hop latency and counters
     */
    public DownstreamClient(
            Map<DownstreamApi, RestClient> downstreamRestClients,
            LegacyRequestRewriter legacyRequestRewriter,
            CircuitBreakerRegistry circuitBreakerRegistry,
            MeterRegistry meterRegistry) {
        this.clients = downstreamRestClients;
        this.legacyRequestRewriter = legacyRequestRewriter;
        this.circuitBreakerRegistry = circuitBreakerRegistry;
        this.meterRegistry = meterRegistry;
    }

    /**
     * Forwards method, path, query, headers, and body to {@code api}.
     * HTTP error statuses are returned as {@link DownstreamResponse} with
     * {@code failoverEligible=false}. Connect/timeout/circuit-open set
     * {@code failoverEligible=true}.
     *
     * @param api          target API
     * @param inbound      original client request
     * @param requestBody  buffered entity
     * @return hop result
     */
    public DownstreamResponse exchange(DownstreamApi api, HttpServletRequest inbound, byte[] requestBody) {
        CircuitBreaker breaker = circuitBreakerRegistry.circuitBreaker(api.name());
        if (!breaker.tryAcquirePermission()) {
            log.warn("Circuit open for downstreamApi={}", api);
            meterRegistry.counter("router.proxy", "api", api.name(), "result", "circuit_open").increment();
            return DownstreamResponse.of(api, 503, new byte[0], Map.of(), true);
        }

        byte[] outboundBody = api == DownstreamApi.LEGACY
                ? legacyRequestRewriter.maybeRewrite(inbound.getRequestURI(), requestBody)
                : requestBody;

        String pathAndQuery = pathAndQuery(inbound);
        Timer.Sample sample = Timer.start(meterRegistry);
        try {
            RestClient client = clients.get(api);
            HttpMethod method = HttpMethod.valueOf(inbound.getMethod());
            ResponseEntity<byte[]> response = client.method(method)
                    .uri(pathAndQuery)
                    .headers(headers -> copyInboundHeaders(inbound, headers))
                    .body(outboundBody == null ? new byte[0] : outboundBody)
                    .retrieve()
                    .toEntity(byte[].class);

            breaker.onSuccess(0, java.util.concurrent.TimeUnit.NANOSECONDS);
            sample.stop(meterRegistry.timer("router.latency", "api", api.name()));
            meterRegistry.counter("router.proxy", "api", api.name(), "result", "success").increment();

            HttpHeaders headers = response.getHeaders();
            return DownstreamResponse.of(
                    api,
                    response.getStatusCode().value(),
                    response.getBody(),
                    headers,
                    false);
        } catch (CallNotPermittedException e) {
            sample.stop(meterRegistry.timer("router.latency", "api", api.name()));
            meterRegistry.counter("router.proxy", "api", api.name(), "result", "circuit_open").increment();
            return DownstreamResponse.of(api, 503, new byte[0], Map.of(), true);
        } catch (Exception e) {
            breaker.onError(0, java.util.concurrent.TimeUnit.NANOSECONDS, e);
            sample.stop(meterRegistry.timer("router.latency", "api", api.name()));
            meterRegistry.counter("router.proxy", "api", api.name(), "result", "error").increment();
            log.warn("Downstream I/O failed api={} reason={}", api, e.toString());
            return DownstreamResponse.of(api, 502, new byte[0], Map.of(), true);
        }
    }

    /**
     * @param request inbound request
     * @return path plus query string when present
     */
    private static String pathAndQuery(HttpServletRequest request) {
        String uri = request.getRequestURI();
        String query = request.getQueryString();
        if (query != null && !query.isEmpty()) {
            return uri + "?" + query;
        }
        return uri;
    }

    /**
     * Copies inbound headers except hop-by-hop, {@code Host}, and {@code Content-Length}.
     *
     * @param request inbound request
     * @param target  RestClient header bag
     */
    private static void copyInboundHeaders(HttpServletRequest request, HttpHeaders target) {
        Enumeration<String> names = request.getHeaderNames();
        if (names == null) {
            return;
        }
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            if (name == null || HOP_BY_HOP.contains(name.toLowerCase(Locale.ROOT))) {
                continue;
            }
            Enumeration<String> values = request.getHeaders(name);
            while (values.hasMoreElements()) {
                target.add(name, values.nextElement());
            }
        }
    }
}
