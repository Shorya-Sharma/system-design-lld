package com.tower.tmapi.router.config;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tower.tmapi.router.model.DownstreamApi;

import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

class RouterConfigTest {

    @Test
    void objectMapperIsUsable() {
        ObjectMapper mapper = new RouterConfig().objectMapper();
        assertThat(mapper).isNotNull();
    }

    @Test
    void restClientsExistForEveryApi() {
        RouterProperties properties = RouterPropertiesTest.validProperties();
        Map<DownstreamApi, RestClient> clients = new RouterConfig().downstreamRestClients(properties);
        assertThat(clients).containsOnlyKeys(
                DownstreamApi.LEGACY, DownstreamApi.OPEN_SEARCH, DownstreamApi.CLICK_HOUSE);
        assertThat(clients.values()).doesNotContainNull();
    }

    @Test
    void circuitBreakersExistForEveryApi() {
        RouterProperties properties = RouterPropertiesTest.validProperties();
        CircuitBreakerRegistry registry = new RouterConfig().circuitBreakerRegistry(properties);
        for (DownstreamApi api : DownstreamApi.values()) {
            assertThat(registry.circuitBreaker(api.name())).isNotNull();
        }
    }
}
