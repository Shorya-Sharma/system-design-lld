package com.tower.tmapi.router.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

class DownstreamResponseTest {

    @Test
    void ofNormalizesNullBodyAndHeaders() {
        DownstreamResponse response = DownstreamResponse.of(
                DownstreamApi.LEGACY, 502, null, null, true);

        assertThat(response.body()).isEmpty();
        assertThat(response.headers()).isEmpty();
        assertThat(response.bodyOrEmpty()).isEmpty();
        assertThat(response.failoverEligible()).isTrue();
        assertThat(response.statusCode()).isEqualTo(502);
        assertThat(response.api()).isEqualTo(DownstreamApi.LEGACY);
    }

    @Test
    void bodyOrEmptyReturnsOriginalBytes() {
        byte[] body = "err".getBytes(StandardCharsets.UTF_8);
        DownstreamResponse response = new DownstreamResponse(
                DownstreamApi.OPEN_SEARCH, 404, body, Map.of("X", List.of("1")), false);

        assertThat(response.bodyOrEmpty()).isEqualTo(body);
        assertThat(response.headers()).containsEntry("X", List.of("1"));
    }

    @Test
    void bodyOrEmptyWhenRecordBodyIsNull() {
        DownstreamResponse response = new DownstreamResponse(
                DownstreamApi.CLICK_HOUSE, 200, null, Map.of(), false);

        assertThat(response.bodyOrEmpty()).isEmpty();
    }
}
