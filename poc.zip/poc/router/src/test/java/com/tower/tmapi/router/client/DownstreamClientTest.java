package com.tower.tmapi.router.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;

import com.tower.tmapi.router.model.DownstreamApi;
import com.tower.tmapi.router.model.DownstreamResponse;
import com.tower.tmapi.router.util.LegacyRequestRewriter;

import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

@ExtendWith(MockitoExtension.class)
class DownstreamClientTest {

    @Mock
    private LegacyRequestRewriter rewriter;

    @Mock
    private CircuitBreakerRegistry circuitBreakerRegistry;

    @Mock
    private CircuitBreaker circuitBreaker;

    private RestClient restClient;
    private DownstreamClient client;

    @BeforeEach
    void setUp() {
        restClient = mock(RestClient.class, RETURNS_DEEP_STUBS);
        Map<DownstreamApi, RestClient> clients = new EnumMap<>(DownstreamApi.class);
        for (DownstreamApi api : DownstreamApi.values()) {
            clients.put(api, restClient);
        }
        when(circuitBreakerRegistry.circuitBreaker(anyString())).thenReturn(circuitBreaker);
        client = new DownstreamClient(clients, rewriter, circuitBreakerRegistry, new SimpleMeterRegistry());
    }

    @Test
    void returnsHttpErrorWithoutFailoverFlag() {
        when(circuitBreaker.tryAcquirePermission()).thenReturn(true);
        byte[] body = "{\"e\":1}".getBytes(StandardCharsets.UTF_8);
        when(restClient.method(any()).uri(anyString()).headers(any()).body(any()).retrieve().toEntity(byte[].class))
                .thenReturn(new ResponseEntity<>(body, HttpStatus.NOT_FOUND));
        MockHttpServletRequest request = request();

        DownstreamResponse response = client.exchange(DownstreamApi.OPEN_SEARCH, request, new byte[0]);

        assertThat(response.statusCode()).isEqualTo(404);
        assertThat(response.failoverEligible()).isFalse();
        assertThat(response.bodyOrEmpty()).isEqualTo(body);
        verify(rewriter, never()).maybeRewrite(any(), any());
    }

    @Test
    void ioFailureIsFailoverEligible() {
        when(circuitBreaker.tryAcquirePermission()).thenReturn(true);
        when(restClient.method(any()).uri(anyString()).headers(any()).body(any()).retrieve().toEntity(byte[].class))
                .thenThrow(new ResourceAccessException("timeout"));

        DownstreamResponse response = client.exchange(DownstreamApi.CLICK_HOUSE, request(), new byte[0]);

        assertThat(response.statusCode()).isEqualTo(502);
        assertThat(response.failoverEligible()).isTrue();
        verify(circuitBreaker).onError(anyLong(), any(TimeUnit.class), any());
    }

    @Test
    void openCircuitReturns503() {
        when(circuitBreaker.tryAcquirePermission()).thenReturn(false);

        DownstreamResponse response = client.exchange(DownstreamApi.LEGACY, request(), new byte[0]);

        assertThat(response.statusCode()).isEqualTo(503);
        assertThat(response.failoverEligible()).isTrue();
        verify(rewriter, never()).maybeRewrite(any(), any());
    }

    @Test
    void rewritesBodyOnlyForLegacy() {
        when(circuitBreaker.tryAcquirePermission()).thenReturn(true);
        byte[] original = "in".getBytes(StandardCharsets.UTF_8);
        byte[] rewritten = "out".getBytes(StandardCharsets.UTF_8);
        when(rewriter.maybeRewrite("/executions/aggregatedExecutions", original)).thenReturn(rewritten);
        when(restClient.method(any()).uri(anyString()).headers(any()).body(rewritten).retrieve().toEntity(byte[].class))
                .thenReturn(new ResponseEntity<>("ok".getBytes(StandardCharsets.UTF_8), HttpStatus.OK));
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/executions/aggregatedExecutions");

        DownstreamResponse response = client.exchange(DownstreamApi.LEGACY, request, original);

        assertThat(response.statusCode()).isEqualTo(200);
        verify(rewriter).maybeRewrite("/executions/aggregatedExecutions", original);
    }

    private static MockHttpServletRequest request() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        request.setQueryString("date=20240701");
        request.addHeader("Access-token", "t");
        request.addHeader("Connection", "keep-alive");
        return request;
    }
}
