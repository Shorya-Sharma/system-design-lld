package com.tower.tmapi.router.model;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.jupiter.api.Test;

class DownstreamApiTest {

    @Test
    void mapsTokenSources() {
        assertThat(DownstreamApi.fromTokenSrc("PROD")).contains(DownstreamApi.LEGACY);
        assertThat(DownstreamApi.fromTokenSrc("OS")).contains(DownstreamApi.OPEN_SEARCH);
        assertThat(DownstreamApi.fromTokenSrc("CH")).contains(DownstreamApi.CLICK_HOUSE);
    }

    @Test
    void tokenSrcValues() {
        assertThat(DownstreamApi.LEGACY.tokenSrc()).isEqualTo("PROD");
        assertThat(DownstreamApi.OPEN_SEARCH.tokenSrc()).isEqualTo("OS");
        assertThat(DownstreamApi.CLICK_HOUSE.tokenSrc()).isEqualTo("CH");
    }

    @Test
    void unknownSourceIsEmpty() {
        assertThat(DownstreamApi.fromTokenSrc(null)).isEqualTo(Optional.empty());
        assertThat(DownstreamApi.fromTokenSrc("")).isEmpty();
        assertThat(DownstreamApi.fromTokenSrc("  ")).isEmpty();
        assertThat(DownstreamApi.fromTokenSrc("NOPE")).isEmpty();
    }
}
