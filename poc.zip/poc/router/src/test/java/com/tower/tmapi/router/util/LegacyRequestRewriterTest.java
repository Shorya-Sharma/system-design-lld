package com.tower.tmapi.router.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

class LegacyRequestRewriterTest {

    private final ObjectMapper mapper = new ObjectMapper();
    private LegacyRequestRewriter rewriter;

    @BeforeEach
    void setUp() {
        rewriter = new LegacyRequestRewriter(mapper);
    }

    @Test
    void rewritesIsoDatesOnAggregatedExecutions() throws Exception {
        byte[] body = """
                {"filterCriteria":{"dateFrom":"2023-10-25T14:30:00","minDate":"2023-10-24T08:00:00"}}
                """.getBytes(StandardCharsets.UTF_8);

        byte[] rewritten = rewriter.maybeRewrite("/executions/aggregatedExecutions", body);
        JsonNode filter = mapper.readTree(rewritten).get("filterCriteria");

        assertThat(filter.get("dateFrom").isArray()).isTrue();
        assertThat(filter.get("dateFrom").get(0).asInt()).isEqualTo(2023);
        assertThat(filter.get("dateFrom").get(1).asInt()).isEqualTo(10);
        assertThat(filter.get("dateFrom").get(2).asInt()).isEqualTo(25);
        assertThat(filter.get("dateFrom").get(3).asInt()).isEqualTo(14);
        assertThat(filter.get("dateFrom").get(4).asInt()).isEqualTo(30);
        assertThat(filter.get("minDate").get(2).asInt()).isEqualTo(24);
    }

    @Test
    void leavesUnrelatedPathsUnchanged() {
        byte[] body = "{\"filterCriteria\":{\"dateFrom\":\"2023-10-25T14:30:00\"}}".getBytes(StandardCharsets.UTF_8);
        byte[] rewritten = rewriter.maybeRewrite("/executions/search", body);
        assertThat(rewritten).isSameAs(body);
    }

    @Test
    void returnsOriginalWhenPathOrBodyMissing() {
        byte[] body = "{}".getBytes(StandardCharsets.UTF_8);
        assertThat(rewriter.maybeRewrite(null, body)).isSameAs(body);
        assertThat(rewriter.maybeRewrite("/executions/aggregatedExecutions", null)).isNull();
        assertThat(rewriter.maybeRewrite("/executions/aggregatedExecutions", new byte[0])).isEmpty();
    }

    @Test
    void rewritesStartAndEndTimeOnRoot() throws Exception {
        byte[] body = """
                {"startTime":"2024-01-02T03:04:00","endTime":"2024-01-02T05:06:00"}
                """.getBytes(StandardCharsets.UTF_8);
        byte[] rewritten = rewriter.maybeRewrite("/executions/getAggregatedTrade/", body);
        JsonNode root = mapper.readTree(rewritten);
        assertThat(root.get("startTime").get(3).asInt()).isEqualTo(3);
        assertThat(root.get("endTime").get(4).asInt()).isEqualTo(6);
    }

    @Test
    void invalidJsonReturnsOriginal() {
        byte[] body = "not-json".getBytes(StandardCharsets.UTF_8);
        assertThat(rewriter.maybeRewrite("/executions/aggregatedExecutions", body)).isSameAs(body);
    }
}
