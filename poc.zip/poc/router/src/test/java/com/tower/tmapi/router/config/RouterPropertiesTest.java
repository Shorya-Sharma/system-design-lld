package com.tower.tmapi.router.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.tower.tmapi.router.model.DownstreamApi;

class RouterPropertiesTest {

    @Test
    void validateAcceptsOrderedCutoversAndUrls() {
        RouterProperties properties = validProperties();
        properties.validate();
        assertThat(properties.baseUrlFor(DownstreamApi.LEGACY)).isEqualTo("http://legacy");
        assertThat(properties.baseUrls()).containsKeys(
                DownstreamApi.LEGACY, DownstreamApi.OPEN_SEARCH, DownstreamApi.CLICK_HOUSE);
    }

    @Test
    void validateRejectsInvertedCutover() {
        RouterProperties properties = validProperties();
        properties.getCutover().setOpensearchStart("20250101");
        properties.getCutover().setClickhouseStart("20240101");
        assertThatThrownBy(properties::validate).isInstanceOf(IllegalStateException.class);
    }

    @Test
    void validateRejectsMissingUrl() {
        RouterProperties properties = validProperties();
        properties.getTargets().remove("clickhouse");
        assertThatThrownBy(properties::validate).isInstanceOf(IllegalStateException.class);
    }

    @Test
    void cutoverParsesBasicIso() {
        RouterProperties properties = validProperties();
        assertThat(properties.getCutover().openSearchStartDate()).isEqualTo(LocalDate.of(2024, 7, 1));
        assertThat(properties.getCutover().clickHouseStartDate()).isEqualTo(LocalDate.of(2024, 9, 1));
    }

    @Test
    void cutoverRejectsBadFormat() {
        RouterProperties.Cutover cutover = new RouterProperties.Cutover();
        cutover.setOpensearchStart("2024-07-01");
        assertThatThrownBy(cutover::openSearchStartDate).isInstanceOf(IllegalStateException.class);
    }

    @Test
    void nullNestedObjectsBecomeDefaults() {
        RouterProperties properties = new RouterProperties();
        properties.setTargets(null);
        properties.setCutover(null);
        properties.setFailover(null);
        properties.setTimeouts(null);
        assertThat(properties.getTargets()).isEmpty();
        assertThat(properties.getCutover()).isNotNull();
        assertThat(properties.getFailover().statusCodeSet()).contains(404, 500, 502, 503, 504);
        assertThat(properties.getTimeouts().getConnectMs()).isEqualTo(5000);
    }

    @Test
    void failoverNullStatusCodesBecomeEmpty() {
        RouterProperties.Failover failover = new RouterProperties.Failover();
        failover.setStatusCodes(null);
        assertThat(failover.getStatusCodes()).isEmpty();
        assertThat(failover.statusCodeSet()).isEmpty();
    }

    @Test
    void exposeHeaderFlag() {
        RouterProperties properties = new RouterProperties();
        properties.setExposeRoutedToHeader(true);
        assertThat(properties.isExposeRoutedToHeader()).isTrue();
    }

    static RouterProperties validProperties() {
        RouterProperties properties = new RouterProperties();
        Map<String, RouterProperties.Target> targets = new HashMap<>();
        targets.put("legacy", target("http://legacy"));
        targets.put("opensearch", target("http://os"));
        targets.put("clickhouse", target("http://ch"));
        properties.setTargets(targets);
        properties.getCutover().setOpensearchStart("20240701");
        properties.getCutover().setClickhouseStart("20240901");
        properties.getFailover().setStatusCodes(List.of(404, 500, 502, 503, 504));
        properties.getFailover().setOnConnectFailure(true);
        return properties;
    }

    private static RouterProperties.Target target(String url) {
        RouterProperties.Target target = new RouterProperties.Target();
        target.setBaseUrl(url);
        return target;
    }
}
