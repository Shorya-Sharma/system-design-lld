package com.tower.tmapi.router.web;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.tower.tmapi.router.config.RouterProperties;
import com.tower.tmapi.router.model.DownstreamApi;
import com.tower.tmapi.router.model.DownstreamResponse;
import com.tower.tmapi.router.service.RouterService;

@ExtendWith(MockitoExtension.class)
class RouterControllerTest {

    @Mock
    private RouterService routerService;

    private RouterProperties properties;
    private RouterController controller;

    @BeforeEach
    void setUp() {
        properties = new RouterProperties();
        properties.setExposeRoutedToHeader(true);
        controller = new RouterController(routerService, properties);
    }

    @Test
    void copiesStatusBodyAndRoutedHeader() throws Exception {
        byte[] requestBody = "{\"a\":1}".getBytes(StandardCharsets.UTF_8);
        byte[] responseBody = "{\"ok\":true}".getBytes(StandardCharsets.UTF_8);
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/executions/search");
        request.setContent(requestBody);
        request.addHeader(RouterController.CORRELATION_HEADER, "cid-1");
        MockHttpServletResponse response = new MockHttpServletResponse();
        when(routerService.route(eq(request), eq(requestBody))).thenReturn(DownstreamResponse.of(
                DownstreamApi.CLICK_HOUSE,
                201,
                responseBody,
                Map.of("X-Downstream", List.of("yes"), "Content-Length", List.of("99")),
                false));

        controller.proxy(request, response);

        assertThat(response.getStatus()).isEqualTo(201);
        assertThat(response.getContentAsByteArray()).isEqualTo(responseBody);
        assertThat(response.getHeader(RouterController.ROUTED_TO_HEADER)).isEqualTo("CLICK_HOUSE");
        assertThat(response.getHeader(RouterController.CORRELATION_HEADER)).isEqualTo("cid-1");
        assertThat(response.getHeader("X-Downstream")).isEqualTo("yes");
        assertThat(response.getHeader("Content-Length")).isEqualTo(String.valueOf(responseBody.length));
        assertThat(response.getContentType()).contains("application/json");
    }

    @Test
    void generatesCorrelationIdWhenMissing() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        MockHttpServletResponse response = new MockHttpServletResponse();
        when(routerService.route(any(), any())).thenReturn(DownstreamResponse.of(
                DownstreamApi.LEGACY, 204, new byte[0], Map.of(), false));

        controller.proxy(request, response);

        assertThat(response.getHeader(RouterController.CORRELATION_HEADER)).isNotBlank();
        assertThat(response.getContentAsByteArray()).isEmpty();
    }

    @Test
    void hidesRoutedHeaderWhenDisabled() throws Exception {
        properties.setExposeRoutedToHeader(false);
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/aggregatedExecutions/x");
        MockHttpServletResponse response = new MockHttpServletResponse();
        when(routerService.route(any(), any())).thenReturn(DownstreamResponse.of(
                DownstreamApi.OPEN_SEARCH, 200, "z".getBytes(StandardCharsets.UTF_8), Map.of(), false));

        controller.proxy(request, response);

        assertThat(response.getHeader(RouterController.ROUTED_TO_HEADER)).isNull();
        ArgumentCaptor<byte[]> body = ArgumentCaptor.forClass(byte[].class);
        verify(routerService).route(eq(request), body.capture());
        assertThat(body.getValue()).isEmpty();
    }
}
