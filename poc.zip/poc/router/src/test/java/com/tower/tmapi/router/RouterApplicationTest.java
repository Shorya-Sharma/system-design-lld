package com.tower.tmapi.router;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.tower.tmapi.router.config.RouterProperties;

class RouterApplicationTest {

    @Test
    void isSpringBootApplication() {
        assertThat(RouterApplication.class.isAnnotationPresent(SpringBootApplication.class)).isTrue();
        EnableConfigurationProperties enabled = RouterApplication.class.getAnnotation(EnableConfigurationProperties.class);
        assertThat(enabled).isNotNull();
        assertThat(enabled.value()).containsExactly(RouterProperties.class);
        assertThat(new RouterApplication()).isNotNull();
    }
}
