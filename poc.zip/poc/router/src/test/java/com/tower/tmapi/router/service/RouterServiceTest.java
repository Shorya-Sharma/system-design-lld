package com.tower.tmapi.router.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tower.tmapi.router.client.DownstreamClient;
import com.tower.tmapi.router.config.RouterProperties;
import com.tower.tmapi.router.config.RouterPropertiesTest;
import com.tower.tmapi.router.model.DownstreamApi;
import com.tower.tmapi.router.model.DownstreamResponse;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

@ExtendWith(MockitoExtension.class)
class RouterServiceTest {

    @Mock
    private DownstreamClient downstreamClient;

    private RouterService routerService;

    @BeforeEach
    void setUp() {
        routerService = new RouterService(
                downstreamClient,
                RouterPropertiesTest.validProperties(),
                new ObjectMapper(),
                new SimpleMeterRegistry());
    }

    @Test
    void missingDateRoutesToLegacyOnly() {
        assertThat(routerService.planRoute(null, null)).containsExactly(DownstreamApi.LEGACY);
    }

    @Test
    void dateBeforeOpenSearchIsLegacy() {
        assertThat(routerService.planRoute(LocalDate.of(2024, 6, 30), null))
                .containsExactly(DownstreamApi.LEGACY);
    }

    @Test
    void dateInOpenSearchWindow() {
        assertThat(routerService.planRoute(LocalDate.of(2024, 7, 1), null))
                .containsExactly(DownstreamApi.OPEN_SEARCH, DownstreamApi.LEGACY);
        assertThat(routerService.planRoute(LocalDate.of(2024, 8, 31), null))
                .containsExactly(DownstreamApi.OPEN_SEARCH, DownstreamApi.LEGACY);
    }

    @Test
    void dateOnOrAfterClickHouse() {
        assertThat(routerService.planRoute(LocalDate.of(2024, 9, 1), null))
                .containsExactly(DownstreamApi.CLICK_HOUSE, DownstreamApi.OPEN_SEARCH, DownstreamApi.LEGACY);
    }

    @Test
    void stickyOverridesDate() {
        assertThat(routerService.planRoute(LocalDate.of(2024, 9, 1), DownstreamApi.OPEN_SEARCH))
                .containsExactly(DownstreamApi.OPEN_SEARCH);
    }

    @Test
    void parseDateFormats() {
        assertThat(RouterService.parseDate("20240715")).contains(LocalDate.of(2024, 7, 15));
        assertThat(RouterService.parseDate("2024-07-15")).contains(LocalDate.of(2024, 7, 15));
        assertThat(RouterService.parseDate("2024-07-15T12:00:00")).contains(LocalDate.of(2024, 7, 15));
        assertThat(RouterService.parseDate(null)).isEqualTo(Optional.empty());
        assertThat(RouterService.parseDate("bad")).isEmpty();
    }

    @Test
    void usesEarliestBodyDateForClickHouseBand() {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/executions/search");
        byte[] body = """
                {"filterCriteria":{"run_date":"20240910","trade_date":"20240801"}}
                """.getBytes(StandardCharsets.UTF_8);
        DownstreamResponse ok = DownstreamResponse.of(
                DownstreamApi.OPEN_SEARCH, 200, "ok".getBytes(StandardCharsets.UTF_8), Map.of(), false);
        when(downstreamClient.exchange(eq(DownstreamApi.OPEN_SEARCH), eq(request), eq(body))).thenReturn(ok);

        DownstreamResponse result = routerService.route(request, body);

        assertThat(result.api()).isEqualTo(DownstreamApi.OPEN_SEARCH);
        verify(downstreamClient, never()).exchange(eq(DownstreamApi.CLICK_HOUSE), any(), any());
    }

    @Test
    void queryDateDrivesMilestones() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        request.setParameter("date", "20240701");
        DownstreamResponse ok = DownstreamResponse.of(
                DownstreamApi.OPEN_SEARCH, 200, "{}".getBytes(StandardCharsets.UTF_8), Map.of(), false);
        when(downstreamClient.exchange(eq(DownstreamApi.OPEN_SEARCH), eq(request), any())).thenReturn(ok);

        assertThat(routerService.route(request, new byte[0]).statusCode()).isEqualTo(200);
    }

    @Test
    void stickyScrollDoesNotFailover() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/executions");
        request.setParameter("lastScrollId", "OS:abc");
        request.setParameter("date", "20240901");
        DownstreamResponse error = DownstreamResponse.of(
                DownstreamApi.OPEN_SEARCH, 500, "fail".getBytes(StandardCharsets.UTF_8), Map.of(), false);
        when(downstreamClient.exchange(eq(DownstreamApi.OPEN_SEARCH), eq(request), any())).thenReturn(error);

        DownstreamResponse result = routerService.route(request, new byte[0]);

        assertThat(result.statusCode()).isEqualTo(500);
        assertThat(result.bodyOrEmpty()).isEqualTo("fail".getBytes(StandardCharsets.UTF_8));
        verify(downstreamClient, times(1)).exchange(any(), any(), any());
    }

    @Test
    void http400IsTerminal() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        request.setParameter("date", "20240901");
        when(downstreamClient.exchange(eq(DownstreamApi.CLICK_HOUSE), eq(request), any()))
                .thenReturn(DownstreamResponse.of(
                        DownstreamApi.CLICK_HOUSE, 400, "bad".getBytes(StandardCharsets.UTF_8), Map.of(), false));

        DownstreamResponse result = routerService.route(request, new byte[0]);

        assertThat(result.statusCode()).isEqualTo(400);
        verify(downstreamClient, times(1)).exchange(any(), any(), any());
    }

    @Test
    void http404FailoversAndKeepsLastBody() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        request.setParameter("date", "20240901");
        when(downstreamClient.exchange(eq(DownstreamApi.CLICK_HOUSE), eq(request), any()))
                .thenReturn(DownstreamResponse.of(
                        DownstreamApi.CLICK_HOUSE, 404, "ch".getBytes(StandardCharsets.UTF_8), Map.of(), false));
        when(downstreamClient.exchange(eq(DownstreamApi.OPEN_SEARCH), eq(request), any()))
                .thenReturn(DownstreamResponse.of(
                        DownstreamApi.OPEN_SEARCH, 404, "os".getBytes(StandardCharsets.UTF_8), Map.of(), false));
        when(downstreamClient.exchange(eq(DownstreamApi.LEGACY), eq(request), any()))
                .thenReturn(DownstreamResponse.of(
                        DownstreamApi.LEGACY, 404, "lg".getBytes(StandardCharsets.UTF_8), Map.of(), false));

        DownstreamResponse result = routerService.route(request, new byte[0]);

        assertThat(result.api()).isEqualTo(DownstreamApi.LEGACY);
        assertThat(new String(result.bodyOrEmpty(), StandardCharsets.UTF_8)).isEqualTo("lg");
        verify(downstreamClient, times(3)).exchange(any(), any(), any());
    }

    @Test
    void ioErrorFailoversToNextSuccess() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        request.setParameter("date", "20240901");
        when(downstreamClient.exchange(eq(DownstreamApi.CLICK_HOUSE), eq(request), any()))
                .thenReturn(DownstreamResponse.of(DownstreamApi.CLICK_HOUSE, 502, new byte[0], Map.of(), true));
        when(downstreamClient.exchange(eq(DownstreamApi.OPEN_SEARCH), eq(request), any()))
                .thenReturn(DownstreamResponse.of(
                        DownstreamApi.OPEN_SEARCH, 200, "ok".getBytes(StandardCharsets.UTF_8), Map.of(), false));

        DownstreamResponse result = routerService.route(request, new byte[0]);

        assertThat(result.statusCode()).isEqualTo(200);
        assertThat(result.api()).isEqualTo(DownstreamApi.OPEN_SEARCH);
    }

    @Test
    void connectFailureDisabledDoesNotFailoverOn502Eligible() {
        RouterProperties properties = RouterPropertiesTest.validProperties();
        properties.getFailover().setOnConnectFailure(false);
        routerService = new RouterService(
                downstreamClient, properties, new ObjectMapper(), new SimpleMeterRegistry());
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/milestones");
        request.setParameter("date", "20240901");
        when(downstreamClient.exchange(eq(DownstreamApi.CLICK_HOUSE), eq(request), any()))
                .thenReturn(DownstreamResponse.of(DownstreamApi.CLICK_HOUSE, 502, new byte[0], Map.of(), true));

        DownstreamResponse result = routerService.route(request, new byte[0]);

        assertThat(result.api()).isEqualTo(DownstreamApi.CLICK_HOUSE);
        verify(downstreamClient, times(1)).exchange(any(), any(), any());
    }
}
